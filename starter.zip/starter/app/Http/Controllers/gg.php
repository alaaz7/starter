<?php

namespace App\Http\Controllers;



class gg extends Controller
{
    public function showUserNames(){
        return 'Alaa alzoubi';
    }
}
