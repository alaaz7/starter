<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;

class FirstController extends Controller
{
    //
}
