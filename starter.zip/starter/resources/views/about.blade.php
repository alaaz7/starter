@extends('layout.master')



@section('content')

<p> About us page </p>
@stop